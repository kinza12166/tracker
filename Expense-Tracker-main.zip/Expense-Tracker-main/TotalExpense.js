function TotalExpense({ expenses }) {
  const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  return <h2>Total: ${total.toFixed(2)}</h2>;
}

export default TotalExpense;
